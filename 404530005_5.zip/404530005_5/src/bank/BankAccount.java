package bank;
import java.util.ArrayList;

public class BankAccount {
	String state,type;
	int accountNumber;
	double deductFees,addInterest;
	int i=0,n=0;
	double x,X,y;//use symbol to count my addInterest
	private double balance;
	ArrayList <Double> transactionList=new ArrayList<Double>();
	
	//constructor
	public BankAccount(){
		this(-1,-1);
	}
	public BankAccount(int anAccountNumber){
		this(anAccountNumber,0);
		}
	public BankAccount(int anAccountNumber,double initialBalance){
	this.state="open";
	this.type="checking";
	this.accountNumber=anAccountNumber;
	this.balance=initialBalance;
	}
	private boolean ischecking(){
		return this.type.equalsIgnoreCase("checking");
	}
	private boolean issavings(){
		return this.type.equalsIgnoreCase("savings    ");
	}
	private boolean isOpen(){
		return this.state.equalsIgnoreCase("open");
		}
	private boolean isSuspended(){
		return this.state.equalsIgnoreCase("suspended");
	}
	private boolean isClosed(){
		return this.state.equalsIgnoreCase("closed");
	}
	void deposit(double amount){
		if(!this.isOpen()||amount<0)
		   {
			//System.out.println("Error!");
		   }
		else
			{
			this.balance+=amount;
			x+=amount;
			X=x-4000;
			//add all the deposit to x
			//because month end before deposit $4000,so need to minus it to count X
			addTransaction(amount);
			 }
		
	}
	
	void withdraw(double amount){
		if(!this.isOpen()||amount<0||amount>balance){
			//System.out.println("Error!");
		}
		else
		{
		amount = 0 - amount;
		this.balance += amount;
		y+=amount;
		addTransaction(amount);
		if(accountNumber>i)
		{n=n+1;} //need to know the number of withdraw
		}
	}
	void deductFees(double amount){
		 if (amount==1001){ //if input deductFees(1001)=(amount=1001) 
		 deductFees =0-((n-3)*2); /*need to minus three free withdrawals per month
		                            ,and charges a $2 transaction fee for each additional withdrawal.*/
		 this.balance += deductFees;
		 addTransaction(amount);
		 }
			}
	void addInterest(double amount){
		if (amount==1002){
		 addInterest=0+((X+y)*(0.1)); //count the addInterest
		this.balance+=((X+y)*(0.1))+400;
		 addTransaction(amount);
		}
		 }

	void checking(){
		this.type="checking";
	}
	void savings(){
		this.type="savings    ";
	}
	
	//change the account status
	void reOpen(){
		this.state="open";
	}
	void suspend(){
		this.state="suspended";
	}
	void close(){
		this.state="closed";
	}
	
	
	
	void addTransaction(double amount){
		this.transactionList.add(amount);
	}//add the amount into the transactionList
	
	int retrieveNumberOfTransactions(){
		return this.transactionList.size();
	}//know the size of transactionList
	
	String getTranscations1(){
		StringBuffer output = new StringBuffer();
		int sum=0;
		for(int i=0;i<this.transactionList.size()-2;i++){
				output.append((i+1)+": "+transactionList.get(i)+"\n");
				}
       		output.append((this.transactionList.size()-1)+": "+deductFees+"\n");
       		//the month end
		for(int i=0;i<this.transactionList.size();i++){
			if(sum<i)
			{sum=i;}
		}
		output.append((this.transactionList.size())+": "+transactionList.get(sum)+"\n");
		return output.toString();
				} 
	String getTranscations2(){
		StringBuffer output = new StringBuffer();
		int sum=0;
		for(int i=0;i<this.transactionList.size()-2;i++){
			output.append((i+1)+": "+transactionList.get(i)+"\n");
		}
		
		output.append((this.transactionList.size()-1)+": "+((X+y)*(0.1))+"\n");
		//the month end
		for(int i=0;i<this.transactionList.size();i++){
			if(sum<i)
			{sum=i;}
		}
	   output.append((this.transactionList.size())+": "+transactionList.get(sum)+"\n");
		
		return output.toString();
		}
		
	String getTranscations3_4(){
		StringBuffer output = new StringBuffer();
		for(int i=0;i<this.transactionList.size();i++){
			output.append((i+1)+": "+transactionList.get(i)+"\n");
		}
		return output.toString();
		}
		
	public double getBalance(){
		return this.balance;
	}
	public int getAccountNumber(){
		return this.accountNumber;
	} 
}
	 