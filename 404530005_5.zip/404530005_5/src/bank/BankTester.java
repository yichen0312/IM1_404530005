package bank;

public class BankTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bank studentBank = new Bank();

		// �򥻴���
		studentBank.addCheckingAccount(1001, 0);
		studentBank.deposit(1001, 500);
		studentBank.deposit(1001, 250);
		studentBank.deposit(1001, 300);
		studentBank.deposit(1001, 50);
		studentBank.deposit(1001, 5000);
		studentBank.withdraw(1001, 500);
		studentBank.withdraw(1001, 500);
		studentBank.withdraw(1001, 500);
		studentBank.withdraw(1001, 500);
		studentBank.withdraw(1001, 500);
		studentBank.deductFees(1001);
		studentBank.withdraw(1001, 3596);
		studentBank.closeAccount(1001);

		studentBank.addSavingsAccount(1002, 0,10);
		studentBank.deposit(1002, 2500);
		studentBank.deposit(1002, 1500);
		studentBank.withdraw(1002, 2000);
		studentBank.withdraw(1002, 500);
		studentBank.addInterest(1002);
		studentBank.deposit(1002, 4000);
		studentBank.suspendAccount(1002);

		studentBank.addCheckingAccount(1003, 0);
		studentBank.deposit(1003, 1000);
		studentBank.deposit(1003, 100);
		studentBank.withdraw(1003, 250);
		studentBank.deposit(1003, 750);
		studentBank.withdraw(1003, 800);
		studentBank.reOpenAccount(1003);

		studentBank.addSavingsAccount(1004, 0,10);
		studentBank.deposit(1004, 750);
		studentBank.deposit(1004, 800);
		studentBank.reOpenAccount(1004);

		System.out.println(studentBank.summarizeAccountTransactions1(1001));
		System.out.println(studentBank.summarizeAccountTransactions2(1002));
		System.out.println(studentBank.summarizeAccountTransactions3_4(1003));
		System.out.println(studentBank.summarizeAccountTransactions3_4(1004));
		

		System.out.println(studentBank.summarizeAllAccounts());
	}

}
