package bank;
import java.util.ArrayList;

public class BankAccount {
	String state;
	int accountNumber;
	private double balance;
	ArrayList <Double> transactionList=new ArrayList<Double>();
	
	//constructor
	public BankAccount(){
		this(-1,-1);
	}
	public BankAccount(int anAccountNumber){
		this(anAccountNumber,0);
		}
	public BankAccount(int anAccountNumber,double initialBalance){
	this.state="open";
	this.accountNumber=anAccountNumber;
	this.balance=initialBalance;
	}
	//check which is the account current state
	private boolean isOpen(){
		return this.state.equalsIgnoreCase("open");
		}
	private boolean isSuspended(){
		return this.state.equalsIgnoreCase("suspended");
	}
	private boolean isClosed(){
		return this.state.equalsIgnoreCase("closed");
	}
	
	void deposit(double amount){
		if(!this.isOpen()||amount<0)
		   {
			//System.out.println("Error!");
		   }
		else
			{
			this.balance+=amount;
			addTransaction(amount);
		    }
	}
	
	void withdraw(double amount){
		if(!this.isOpen()||amount<0||amount>balance){
			//System.out.println("Error!");
		}
		else
		{
		amount = 0 - amount;
		this.balance += amount;
		addTransaction(amount);
		}
	}
	
	//change the account status
	void reOpen(){
		this.state="open";
	}
	void suspend(){
		this.state="suspended";
	}
	void close(){
		this.state="closed";
	}
	
	void addTransaction(double amount){
		this.transactionList.add(amount);
	}//add the amount into the transactionList
	
	int retrieveNumberOfTransactions(){
		return this.transactionList.size();
	}//know the size of transactionList
	
	String getTranscations(){
		StringBuffer output = new StringBuffer();
		for(int i=0;i<this.transactionList.size();i++){
			output.append((i+1)+": "+transactionList.get(i)+"\n");
		}
		return output.toString();
		} 
	public double getBalance(){
		return this.balance;
	}
	
	public int getAccountNumber(){
		return this.accountNumber;
	} 
}
	