package bank;
import java.util.HashMap;
public class Bank {
	HashMap<Integer,BankAccount>accountlist=new HashMap<Integer,BankAccount>();
	/*HashMap<K,V>
	K - the type of keys maintained by this map
	V - the type of mapped values
	�i�Q��(��J)key�Ȩ��t���ovalue*/
	
	void addAccount(int accountNumber,double initialBalance){
		if(initialBalance<0)
		   initialBalance=0;//make sure that the initial balance is not less than 0
		accountlist.put(accountNumber, new BankAccount(accountNumber, initialBalance));
	}
	void deposit(int accountNumber,double initialBalance){
		BankAccount studentaccount=(BankAccount)accountlist.get(accountNumber);
		try{
		studentaccount.deposit(initialBalance);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			}
		}
	void withdraw(int accountNumber,double initialBalance){
		BankAccount studentaccount=(BankAccount)accountlist.get(accountNumber);
		try{
			studentaccount.withdraw(initialBalance);
			}
		catch(Exception e){
			System.out.println(e.getMessage());
			}
		}
	double getBalance(int accountNumber){
		BankAccount studentaccount=(BankAccount)accountlist.get(accountNumber);
		return studentaccount.getBalance();
	}
	
	String getAccountStatus(int accountNumber){
		BankAccount studentaccount=(BankAccount)accountlist.get(accountNumber);
		return studentaccount.state;
	}
	String summarizeAccountTransactions(int accountNumber){
		StringBuffer output = new StringBuffer();
		//String ����Q�]�p���ʺA��  ��  StringBuffer �]�p�λP�ЫةM�ާ@�ʺA�r�Ŧ�H��   �i�f�tappend�ϥ�
		
		BankAccount studentaccount=(BankAccount)accountlist.get(accountNumber);
		output.append("Account # "+accountNumber+" transactions:\n\n"); 
		output.append(studentaccount.getTranscations());
		output.append("End of transactions\n\n");
		return output.toString();
	}
	String summarizeAllAccounts(){
		StringBuffer output = new StringBuffer();
		output.append("Bank Account Summary\n\n"); 
		output.append("Account\t\tBalance\t\t#Transaction\tStatus\n");
		
		/*for�t�@�ث��A:�ϥ� Collection�ΰ}�C (array)�ɡA
		�i�H�b�p�A���������ŧi�@�ӻP Collection�ΰ}�C�ۦP��ƫ��A���ܼơA
		�M��i�H�b�j�餤���C�@���ǥѳo���ܼƨ̧Ǩ��o������*/
	    for (BankAccount bank:accountlist.values()){
			output.append(bank.accountNumber+"\t\t");
			output.append(bank.getBalance()+"\t\t");
			output.append(bank.retrieveNumberOfTransactions()+"\t\t");
			output.append(bank.state+"\n");
		}
		output.append("End of Account Summary \n");
		return output.toString();
 	}

	void suspendAccount(int accountNumber){
	BankAccount studentaccount=(BankAccount)accountlist.get(accountNumber);
	studentaccount.suspend();
						    }

	void reOpenAccount(int accountNumber){
	BankAccount studentaccount=(BankAccount)accountlist.get(accountNumber);
	studentaccount.reOpen();
						    }

	void closeAccount(int accountNumber){
	BankAccount studentaccount=(BankAccount)accountlist.get(accountNumber);
	studentaccount.close();
	}
}		


